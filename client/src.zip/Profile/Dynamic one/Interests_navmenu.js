import React from "react";

const Interests_navmenu = ({ title }) => {
  return (
    <>
      <a href="#">{title}</a>
    </>
  );
};

export default Interests_navmenu;
