import React from "react";

const Skills = ({ title }) => {
  return (
    <>
      <h4>{title}</h4>
    </>
  );
};

export default Skills;
