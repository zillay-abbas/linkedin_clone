import React from "react";

import "./Institute.css";

const Institute = () => {
  return (
    <div className="institute_cont">
      <div className="institute_name">Comsats University Islamabad</div>

      <div className="institute_det">Lorem ipsum dolor sit amet consectetur adipisicing elit.</div>
    </div>
  );
};

export default Institute;
