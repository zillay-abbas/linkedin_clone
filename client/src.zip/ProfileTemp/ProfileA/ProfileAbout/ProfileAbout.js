import React from "react";

import "./ProfileAbout.css";

const PersonStat = () => {
  return (
    <div className="a_about">
      <div className="a_about_head">About</div>

      <div className="a_about_des">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. 
      Voluptatum ipsam praesentium dolorem. Et, pariatur deserunt 
      minus iste officia cupiditate repellat exercitationem necessitatibus neque? 
      Quos iure cumque similique laborum? Rerum, similique.
      </div>
    </div>
  );
};

export default PersonStat;
