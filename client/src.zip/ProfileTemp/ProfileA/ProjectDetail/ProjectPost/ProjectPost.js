import React from 'react';

import "./ProjectPost.css";

const ProjectPost = () => {
  return (
    <div className='post_cont'>
      <>This is Post</>
    </div>
  )
}

export default ProjectPost;